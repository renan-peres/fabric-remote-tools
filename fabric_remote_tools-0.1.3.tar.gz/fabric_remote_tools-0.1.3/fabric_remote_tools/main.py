from azure.identity import DefaultAzureCredential, ClientSecretCredential ,InteractiveBrowserCredential, TokenCachePersistenceOptions
from azure.storage.filedatalake import DataLakeServiceClient, FileSystemClient, DataLakeFileClient
from azure.devops.connection import Connection 
from azure.devops.credentials import BasicAuthentication
from azure.core.exceptions import ResourceNotFoundError
from deltalake import DeltaTable

import os
import io
import json
import requests
import base64
import zipfile
from datetime import datetime, timezone, timedelta
import pytz
from typing import Union, Optional, Generator, List, Tuple, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
import tempfile
import time

import duckdb
import polars as pl

class FabricAuth:

    @staticmethod
    def get_DefaultAzureCredential() -> DefaultAzureCredential:
        """
        Retrieves a DefaultAzureCredential object for service principal authentication.

        This function returns a DefaultAzureCredential, which can be used to authenticate 
        with Azure services using a service principal. It uses the default Azure 
        authentication flow, which attempts to authenticate using multiple methods 
        in a specific order, with emphasis on service principal credentials.

        Returns:
            DefaultAzureCredential: An object that can be used for Azure authentication 
                                    using service principal credentials.

        Note:
            Ensure that the necessary environment variables or configuration files 
            for service principal authentication are properly set up in your environment.
        """
        return DefaultAzureCredential()
    
    @staticmethod
    def get_ClientSecretCredential(client_id: str = None, client_secret: str = None, tenant_id: str = None) -> dict:
        """
        Authenticate with Azure using a client secret credential and obtain storage options for Microsoft Fabric.

        This function authenticates with Azure using the provided client ID, client secret, and tenant ID,
        or reads them from environment variables if not provided. It then obtains an access token and
        returns a dictionary containing the access token (bearer_token) and a flag to use the Fabric endpoint.

        Args:
            client_id (str, optional): The client ID for authentication. If not provided, it will be read from the
                environment variable 'AZURE_CLIENT_ID'.
            client_secret (str, optional): The client secret for authentication. If not provided, it will be read from the
                environment variable 'AZURE_CLIENT_SECRET'.
            tenant_id (str, optional): The tenant ID for authentication. If not provided, it will be read from the
                environment variable 'AZURE_TENANT_ID'.

        Returns:
            dict: A dictionary containing the following keys:
                - bearer_token (str): The access token obtained from authentication.
                - use_fabric_endpoint (str): A flag indicating to use the Fabric endpoint ("true").

        Raises:
            ValueError: If any of the required values (client_id, client_secret, tenant_id) are not set
                (either via arguments or environment variables).
        """
        # If not provided, read from environment variables
        if not client_id:
            client_id = os.getenv("AZURE_CLIENT_ID")
        if not client_secret:
            client_secret = os.getenv("AZURE_CLIENT_SECRET")
        if not tenant_id:
            tenant_id = os.getenv("AZURE_TENANT_ID")

        # Check if required values are set
        if not (client_id and client_secret and tenant_id):
            raise ValueError("One or more required values (client_id, client_secret, tenant_id) are not set.")

        # Authenticate and obtain access token
        credential = ClientSecretCredential(client_id=client_id, client_secret=client_secret, tenant_id=tenant_id)
        token = credential.get_token("https://storage.azure.com/.default").token

        # Prepare storage options as a JSON string
        storage_options = {"bearer_token": token, "use_fabric_endpoint": "true"}

        return storage_options

    @staticmethod
    def get_InteractiveBrowserCredential(token_file: str) -> str:
        """
        Retrieves or generates an interactive browser token for authentication with Microsoft Fabric services.

        This function manages the lifecycle of the interactive browser token, including caching, 
        refreshing, and storing the token. It attempts to load a cached token from a file, and 
        if the token is expired or not found, it generates a new one using an interactive browser flow.

        Args:
            token_file (str): The path to the file where the token will be cached.

        Returns:
            str: A valid interactive browser token that can be used for authentication.

        Note:
            This function handles token caching, refreshing, and conversion between UTC and 
            Eastern Time internally. It uses InteractiveBrowserCredential for new token acquisition, 
            which may prompt the user to log in through a web browser if necessary.
        """
        def _convert_to_eastern_time(timestamp: int) -> datetime:
            utc_time = datetime.fromtimestamp(timestamp, tz=timezone.utc)
            eastern = pytz.timezone("US/Eastern")
            return utc_time.astimezone(eastern)

        def _save_token_to_file(token: str, expiration_timestamp: int):
            with open(token_file, "w") as file:
                json.dump({"token": token, "expires_on": expiration_timestamp}, file)
            print(f"Token and expiration date saved to {token_file}")

        def _load_token_from_file() -> tuple:
            if os.path.exists(token_file):
                try:
                    with open(token_file, "r") as file:
                        data = json.load(file)
                        expiration_date = _convert_to_eastern_time(data["expires_on"])
                        if datetime.now(timezone.utc) < expiration_date:
                            return data["token"], expiration_date
                except (KeyError, json.JSONDecodeError, ValueError) as e:
                    print(f"Error reading token file: {e}")
            return None, None

        def _get_new_token() -> tuple:
            credential = InteractiveBrowserCredential(cache_persistence_options=TokenCachePersistenceOptions())
            access_token = credential.get_token("https://api.fabric.microsoft.com/.default")
            expiration_date = _convert_to_eastern_time(access_token.expires_on)
            _save_token_to_file(access_token.token, access_token.expires_on)
            return access_token.token, expiration_date

        token, expiration_date = _load_token_from_file()
        if not token or datetime.now(timezone.utc) >= expiration_date - timedelta(minutes=5):
            print("Fetching a new token...")
            token, expiration_date = _get_new_token()
        else:
            print("Using cached token...")
        print(f"Token expires on (Eastern Time): {expiration_date}")
        return token
    
    @staticmethod
    def get_FileSystemClient(token_credential: DefaultAzureCredential, account_name: str, workspace_id: str) -> FileSystemClient:
        """
        Creates and returns a FileSystemClient for interacting with Microsoft Fabric's OneLake storage.

        This function sets up a client that can be used to perform operations on the file system 
        within a specific Fabric workspace.

        Args:
            token_credential (get_service_principal_token() or get_interactive_browser_token()): The credential object used for authentication.
            account_name (str): The name of the storage account.
            workspace_id (str): The ID of the Fabric workspace.

        Returns:
            FileSystemClient: A client object that can be used to interact with the file system 
                            in the specified Fabric workspace.

        Note:
            This client can be used for operations like creating directories, uploading files, 
            and managing access control within the OneLake storage of the specified workspace.
        """
        return DataLakeServiceClient(
            f"https://{account_name}.dfs.fabric.microsoft.com",
            credential=token_credential
        ).get_file_system_client(workspace_id)

class OneLakeUtils:
    @staticmethod
    def get_azure_repo_connection(organization_url: str, personal_access_token: str) -> Connection:
        return Connection(base_url=organization_url, creds=BasicAuthentication('', personal_access_token))

    @staticmethod
    def upload_file(file_client: DataLakeFileClient, local_path: str, relative_path: str) -> Tuple[bool, str]:
        try:
            file_size = os.path.getsize(local_path)
            chunk_size = 4 * 1024 * 1024  # 4 MB chunks

            with open(local_path, "rb") as file:
                if file_size <= chunk_size:
                    file_client.upload_data(file.read(), overwrite=True)
                else:
                    file_client.create_file()
                    for i in range(0, file_size, chunk_size):
                        chunk = file.read(chunk_size)
                        file_client.append_data(data=chunk, offset=i)
                    file_client.flush_data(file_size)

            return True, relative_path
        except Exception as error:
            return False, f"Error uploading '{relative_path}': {str(error)}"

    @staticmethod
    def upload_folder(file_system_client: FileSystemClient, source: str, target: str, lakehouse_id: str, verbose: bool = True) -> None:
        try:
            files_to_upload = [(os.path.join(root, file), os.path.relpath(os.path.join(root, file), source).replace('\\', '/'))
                               for root, _, files in os.walk(source)
                               for file in files]

            if verbose:
                source_description = "local Delta Table" if target.startswith("Tables/") else "local folder"
                print(f"Uploading {len(files_to_upload)} files from {source_description} '{source}' to '{target}'")

            with ThreadPoolExecutor(max_workers=10) as executor:
                future_to_file = {
                    executor.submit(
                        OneLakeUtils.upload_file,
                        file_system_client.get_file_client(f"{lakehouse_id}/{os.path.join(target, relative_path)}"),
                        local_path,
                        relative_path
                    ): (local_path, relative_path) for local_path, relative_path in files_to_upload
                }

                uploaded_count = sum(1 for future in as_completed(future_to_file) if future.result()[0])

            print(f"Successfully uploaded {uploaded_count} out of {len(files_to_upload)} files to '{target}'")
        except Exception as error:
            print(f"Error uploading to '{target}': {error}")

    @staticmethod
    def upload_github_repo(file_system_client: FileSystemClient, repo_url: str, target_path: str, lakehouse_id: str, folder_path: str = None) -> None:
        try:
            owner, repo = repo_url.rstrip('/').split('/')[-2:]
            if repo.endswith('.git'):
                repo = repo[:-4]

            zip_url = f"https://github.com/{owner}/{repo}/archive/refs/heads/main.zip"
            response = requests.get(zip_url)
            response.raise_for_status()

            with io.BytesIO(response.content) as zip_buffer, zipfile.ZipFile(zip_buffer) as zip_file:
                files_to_upload = [
                    (name, zip_file.read(name))
                    for name in zip_file.namelist()
                    if not name.endswith('/') and (not folder_path or name.startswith(f"{repo}-main/{folder_path}"))
                ]

            source_description = "GitHub Delta Table" if target_path.startswith("Tables/") else f"GitHub {'folder' if folder_path else 'repository'}"
            print(f"Uploading {len(files_to_upload)} files from {source_description} to '{target_path}'")

            OneLakeUtils._upload_files_from_memory(file_system_client, files_to_upload, target_path, lakehouse_id, folder_path, repo)

        except requests.RequestException as e:
            print(f"Failed to download repository: {str(e)}")
        except Exception as e:
            print(f"Failed to upload {source_description}: {str(e)}")

    @staticmethod
    def upload_private_github_repo(file_system_client: FileSystemClient, repo_name: str, target_path: str, lakehouse_id: str, github_token: str, github_username: str, folder_path: str = None) -> None:
        try:
            api_url = f"https://api.github.com/repos/{github_username}/{repo_name}/zipball"
            headers = {
                "Authorization": f"token {github_token}",
                "Accept": "application/vnd.github.v3+json"
            }
            response = requests.get(api_url, headers=headers)
            response.raise_for_status()

            with io.BytesIO(response.content) as zip_buffer, zipfile.ZipFile(zip_buffer) as zip_file:
                files_to_upload = [
                    (name, zip_file.read(name))
                    for name in zip_file.namelist()
                    if not name.endswith('/') and (not folder_path or name.startswith(folder_path))
                ]

            source_description = "GitHub private Delta Table" if target_path.startswith("Tables/") else "GitHub private repository"
            print(f"Uploading {len(files_to_upload)} files from {source_description} to '{target_path}'")

            OneLakeUtils._upload_files_from_memory(file_system_client, files_to_upload, target_path, lakehouse_id, folder_path)

        except requests.RequestException as e:
            print(f"Failed to download repository: {str(e)}")
        except Exception as e:
            print(f"Failed to upload {source_description}: {str(e)}")

    @staticmethod
    def upload_azure_devops_repo(file_system_client: FileSystemClient, project_name: str, repo_name: str, target_path: str, lakehouse_id: str, organization_url: str, personal_access_token: str, folder_path: str = None) -> None:
        try:
            connection = OneLakeUtils.get_azure_repo_connection(organization_url, personal_access_token)
            git_client = connection.clients.get_git_client()

            repository = git_client.get_repository(repo_name, project_name)
            if not repository:
                raise ValueError(f"Repository not found in project '{project_name}'")

            items = [item for item in git_client.get_items(repository.id, recursion_level='full') 
                     if not item.is_folder and (not folder_path or item.path.startswith(folder_path))]
            
            source_description = "Azure DevOps Delta Table" if target_path.startswith("Tables/") else "Azure DevOps repository"
            print(f"Uploading {len(items)} files from {source_description} to '{target_path}'")

            files_to_upload = [
                (item.path, git_client.get_item_content(repository.id, path=item.path))
                for item in items
            ]

            OneLakeUtils._upload_files_from_memory(file_system_client, files_to_upload, target_path, lakehouse_id, folder_path)

        except Exception as e:
            print(f"Failed to upload {source_description}: {str(e)}")

    @staticmethod
    def _upload_files_from_memory(file_system_client: FileSystemClient, files_to_upload: List[Tuple[str, Union[bytes, Generator]]], target_path: str, lakehouse_id: str, folder_path: str = None, repo_prefix: str = None) -> None:
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = []
            for file_path, content in files_to_upload:
                relative_path = file_path.split('/', 1)[1] if repo_prefix else file_path
                if folder_path:
                    relative_path = relative_path[len(folder_path.lstrip('/')):]
                full_path = f"{lakehouse_id}/{target_path}/{relative_path}"
                file_client = file_system_client.get_file_client(full_path)
                futures.append(executor.submit(OneLakeUtils._upload_file_content, file_client, content, relative_path))

            uploaded_count = sum(1 for future in as_completed(futures) if future.result())

        print(f"Successfully uploaded {uploaded_count} out of {len(files_to_upload)} files to '{target_path}'")

    @staticmethod
    def _upload_file_content(file_client: DataLakeFileClient, content: Union[bytes, Generator], file_name: str) -> bool:
        try:
            if isinstance(content, bytes):
                file_client.upload_data(content, overwrite=True)
            else:
                file_client.upload_data(b"".join(content), overwrite=True)
            return True
        except Exception as e:
            print(f"Error uploading {file_name}: {str(e)}")
            return False

    @staticmethod
    def write_to_lakehouse(file_system_client: FileSystemClient, target_path: str, upload_from: str, lakehouse_id: str, source_path: str = "", connection: Union[Connection, None] = None, folder_path: str = None, project_name: str = None, repo_name: str = None, organization_url: str = None, personal_access_token: str = None, github_token: str = None, github_username: str = None) -> None:
        if upload_from == "local":
            OneLakeUtils._write_local_to_lakehouse(file_system_client, target_path, lakehouse_id, source_path)
        elif upload_from == "git" and connection:
            OneLakeUtils._write_git_to_lakehouse(file_system_client, target_path, lakehouse_id, source_path, connection, project_name, repo_name)
        elif upload_from == "github":
            OneLakeUtils.upload_github_repo(file_system_client, source_path, target_path, lakehouse_id, folder_path)
        elif upload_from == "github_private":
            OneLakeUtils.upload_private_github_repo(file_system_client, repo_name or os.getenv("GITHUB_REPO_NAME"), target_path, lakehouse_id, github_token, github_username, folder_path)
        elif upload_from == "azure_devops":
            OneLakeUtils.upload_azure_devops_repo(file_system_client, project_name or os.getenv("PROJECT_NAME"), repo_name or os.getenv("REPO_NAME"), target_path, lakehouse_id, organization_url, personal_access_token, folder_path)
        else:
            print(f"Invalid upload_from value: '{upload_from}' or missing connection")

    @staticmethod
    def _write_local_to_lakehouse(file_system_client: FileSystemClient, target_path: str, lakehouse_id: str, source_path: str) -> None:
        if os.path.isdir(source_path):
            is_multiple_tables = target_path == "Tables/" and any(os.path.isdir(os.path.join(source_path, d)) for d in os.listdir(source_path))
            if is_multiple_tables:
                print(f"Uploading multiple tables from '{source_path}' to '{target_path}'")
                with ThreadPoolExecutor(max_workers=5) as executor:
                    futures = [
                        executor.submit(OneLakeUtils.upload_folder, file_system_client, os.path.join(source_path, table_name), f"{target_path}{table_name}", lakehouse_id, verbose=False)
                        for table_name in os.listdir(source_path)
                        if os.path.isdir(os.path.join(source_path, table_name))
                    ]
                    for future in as_completed(futures):
                        future.result()
            else:
                source_description = "local Delta Table" if target_path.startswith("Tables/") else "local folder"
                print(f"Uploading {source_description} '{source_path}' to '{target_path}'")
                OneLakeUtils.upload_folder(file_system_client, source_path, target_path, lakehouse_id, verbose=False)
        elif os.path.isfile(source_path):
            data_path = f"{lakehouse_id}/{target_path}"
            file_client = file_system_client.get_file_client(data_path)
            print(f"Uploading local file '{source_path}' to '{target_path}'")
            OneLakeUtils.upload_file(file_client, source_path, os.path.basename(source_path))
        else:
            print(f"Invalid source path: '{source_path}'")

    @staticmethod
    def _write_git_to_lakehouse(file_system_client: FileSystemClient, target_path: str, lakehouse_id: str, source_path: str, connection: Connection, project_name: str, repo_name: str) -> None:
        data_path = f"{lakehouse_id}/{target_path}"
        file_client = file_system_client.get_file_client(data_path)
        print(f"Uploading from git '{source_path}' to '{target_path}'")
        file_content = OneLakeUtils.read_file_from_repo(connection, source_path, project_name, repo_name)
        content_str = "".join([chunk.decode('utf-8') for chunk in file_content])
        file_client.upload_data(content_str, overwrite=True)

    @staticmethod
    def read_file_from_repo(connection: Connection, file_path: str, project_name: str, repo_name: str) -> Generator[bytes, None, None]:
        git_client = connection.clients.get_git_client()
        repository = git_client.get_repository(repo_name, project_name)
        return git_client.get_item_content(repository.id, path=file_path)

    @staticmethod
    def read_deltalake(file_system_client: FileSystemClient, table_path: str, engine: str, version: int = None, row_limit: int = None):
        """
        Read a delta table from OneLake storage using the specified engine and version.

        Args:
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            table_path (str): The path to the delta table within the Lakehouse, e.g., 'Tables/table_name'.
            engine (str): The engine to use for reading the delta table. Supported options: 'duckdb', 'polars'.
            version (int, optional): The specific version of the delta table to read. If not provided, the latest version will be used.
            row_limit (int, optional): The maximum number of rows to retrieve from the delta table. If not provided, all rows will be retrieved.

        Returns:
            Optional[pd.DataFrame]: The loaded delta table as a pandas DataFrame, or None if read failed.
        """

        try:
            # Initialize the DeltaTable with version if provided
            if version is not None:
                dt = DeltaTable(table_path, storage_options=file_system_client, version=version)
            else:
                dt = DeltaTable(table_path, storage_options=file_system_client)

            if engine.lower() == "duckdb":
                df_arrow = dt.to_pyarrow_dataset()
                if row_limit:
                    return duckdb.sql(f"PRAGMA disable_print_progress_bar; SELECT * FROM df_arrow LIMIT {row_limit};")
                else:
                    return duckdb.sql("PRAGMA disable_print_progress_bar; SELECT * FROM df_arrow;")
            elif engine.lower() == "polars":
                # For Polars, we need to use the file paths from the DeltaTable
                files = dt.files()
                full_paths = [f"{table_path}/{file}" for file in files]
                
                if row_limit:
                    return pl.scan_parquet(full_paths, storage_options=file_system_client).limit(row_limit).collect()
                else:
                    return pl.scan_parquet(full_paths, storage_options=file_system_client).collect()
            else:
                print(f"[E] Invalid engine: '{engine}'. Supported engines: 'duckdb', 'polars'")
                return None
        except Exception as e:
            print(f"[E] Error reading delta table: {str(e)}")
            return None

    @staticmethod
    def list_items(file_system_client: FileSystemClient, target_directory_path: str, lakehouse_id: str, print_output: bool = False) -> Optional[List[str]]:
        """
        List items in a directory in OneLake storage.

        Args:
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            target_directory_path (str): The target directory path in OneLake storage.
            lakehouse_id (str): The ID of the lakehouse.
            print_output (bool, optional): Whether to print the output. Defaults to False.

        Returns:
            Optional[List[str]]: A list of item names if print_output is False, otherwise None.
        """
        filtered_names = []
        try:
            lakehouse_path = f"{lakehouse_id}/{target_directory_path}"
            paths = file_system_client.get_paths(path=lakehouse_path)
            for path in paths:
                name = path.name.split('/')[-1]
                if target_directory_path == "Tables" and path.is_directory and "_delta_log" not in name and "YEAR" not in name and "_temporary" not in name:
                    filtered_names.append(name)
                elif target_directory_path == "Files" and "_delta_log" not in name and "YEAR" not in name:
                    filtered_names.append(name)
        except Exception as error:
            print(f"[E] Error listing items: {error}")

        if print_output:
            OneLakeUtils.list_files(file_system_client, target_directory_path, lakehouse_id, is_tables=(target_directory_path == "Tables"))
            return None
        return filtered_names

    @staticmethod
    def list_files(file_system_client: FileSystemClient, target_file_path: str, lakehouse_id: str, indent: str = "", printed_directories: set = None, printed_files: set = None, first_call: bool = True, is_tables: bool = False) -> None:
        """
        List files and directories in OneLake storage.

        Args:
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            target_file_path (str): The target file or directory path in OneLake storage.
            lakehouse_id (str): The ID of the lakehouse.
            indent (str, optional): The indentation for the output. Defaults to "".
            printed_directories (set, optional): Set of already printed directories. Defaults to None.
            printed_files (set, optional): Set of already printed files. Defaults to None.
            first_call (bool, optional): Whether this is the first call to the function. Defaults to True.
            is_tables (bool, optional): Whether the listing is for Tables. Defaults to False.
        """
        if printed_directories is None:
            printed_directories = set()
        if printed_files is None:
            printed_files = set()

        if first_call:
            print(target_file_path + '/')
            first_call = False

        try:
            lakehouse_path = f"{lakehouse_id}/{target_file_path}"
            paths = file_system_client.get_paths(path=lakehouse_path)

            for path in paths:
                name = path.name.split('/')[-1]
                if name not in printed_directories and name not in printed_files and "_delta_log" not in name and "YEAR" not in name:
                    if path.is_directory:
                        print(f"{indent}└── {name}/")
                        printed_directories.add(name)
                        OneLakeUtils.list_files(file_system_client, f"{target_file_path}/{name}", lakehouse_id, indent + "    ", printed_directories, printed_files, first_call=False, is_tables=is_tables)
                    elif not is_tables or target_file_path != "Tables":
                        print(f"{indent}{'    ' if is_tables else ''}└── {name}")
                        printed_files.add(name)
        except Exception as error:
            print(f"[E] Error listing files: {error}")

    @staticmethod
    def download_from_lakehouse(
        file_system_client: FileSystemClient, 
        target_file_path: str, 
        lakehouse_id: str,
        filter_func: Optional[Callable[[str], bool]] = None
    ) -> str:
        """
        Download a file or folder from OneLake storage to the current directory, preserving the directory structure.

        Args:
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            target_file_path (str): The target file or folder path in OneLake storage.
            lakehouse_id (str): The ID of the lakehouse.
            filter_func (Optional[Callable[[str], bool]]): A function that takes a path and returns True if the path should be processed, False otherwise.

        Returns:
            str: The local path of the downloaded file or folder.
        """
        lakehouse_path = f"{lakehouse_id}/{target_file_path}"
        local_base_path = os.getcwd()
        local_path = os.path.join(local_base_path, target_file_path)
        os.makedirs(os.path.dirname(local_path), exist_ok=True)

        try:
            # Check if the path exists
            path_exists = any(file_system_client.get_paths(path=lakehouse_path, max_results=1))
            if not path_exists:
                print(f"The path '{target_file_path}' does not exist in the lakehouse.")
                OneLakeUtils.print_available_paths(file_system_client, lakehouse_id, target_file_path)
                return None

            paths = list(file_system_client.get_paths(path=lakehouse_path))
            
            if not paths:
                print(f"No files found in '{target_file_path}'")
                return local_path

            # Apply filter_func if provided
            if filter_func:
                paths = [path for path in paths if filter_func(path.name)]

            total_files = len([path for path in paths if not path.is_directory])
            print(f"Found {total_files} files to download.")

            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = []
                for path in paths:
                    if path.is_directory:
                        continue
                    relative_path = os.path.relpath(path.name, lakehouse_path)
                    local_file_path = os.path.join(local_path, relative_path)
                    os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
                    file_client = file_system_client.get_file_client(path.name)
                    futures.append(executor.submit(OneLakeUtils.download_file, file_client, local_file_path))

                for i, future in enumerate(as_completed(futures), 1):
                    try:
                        future.result()
                        if i % 10 == 0 or i == total_files:
                            print(f"Progress: {i}/{total_files} files downloaded")
                    except Exception as e:
                        print(f"Error downloading a file: {str(e)}")

            return local_path
        except ResourceNotFoundError:
            print(f"The path '{target_file_path}' does not exist in the lakehouse.")
            OneLakeUtils.print_available_paths(file_system_client, lakehouse_id, target_file_path)
            return None
        except Exception as e:
            print(f"Error downloading '{target_file_path}': {str(e)}")
            return None
    
    @staticmethod
    def print_available_paths(file_system_client: FileSystemClient, lakehouse_id: str, target_file_path: str):
        """
        Print available paths in the lakehouse when a target path is not found.

        Args:
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            lakehouse_id (str): The ID of the lakehouse.
            target_file_path (str): The target file or folder path that was not found.
        """
        print("Available paths:")
        parent_path = os.path.dirname(target_file_path)
        lakehouse_parent_path = f"{lakehouse_id}/{parent_path}"
        
        try:
            paths = list(file_system_client.get_paths(path=lakehouse_parent_path))
            if not paths and parent_path != "":
                # If no paths found and we're not at the root, try listing the root
                paths = list(file_system_client.get_paths(path=lakehouse_id))
                print("No paths found at the specified level. Showing root level paths:")
            
            for path in paths:
                relative_path = path.name.replace(f"{lakehouse_id}/", "", 1)
                print(f"  - {relative_path}")
                
            if not paths:
                print("No paths found in the lakehouse.")
        except Exception as e:
            print(f"Error listing paths: {str(e)}")
        
        print("\nPlease check the path and try again.")

    @staticmethod
    def download_file(file_client: DataLakeFileClient, local_path: str) -> None:
        """
        Download a single file from OneLake storage.

        Args:
            file_client (DataLakeFileClient): The file client for the source file.
            local_path (str): The local path to save the downloaded file.
        """
        with open(local_path, "wb") as file_handle:
            download = file_client.download_file()
            download.readinto(file_handle)

    @staticmethod
    def delete_file(file_system_client: FileSystemClient, lakehouse_dir_path: str, lakehouse_id: str) -> None:
        """
        Deletes files, tables, folders, or all tables/files from OneLake storage.

        This method can handle various deletion scenarios:
        - Deleting a single file
        - Deleting a single table
        - Deleting a folder
        - Deleting all tables
        - Deleting all files

        Args:
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            lakehouse_dir_path (str): The path of the item to delete in OneLake storage.
                Use "Tables/" to delete all tables.
                Use "Files/" to delete all files.
                Use "Tables/table_name" to delete a specific table.
                Use "Files/path/to/file_or_folder" to delete a specific file or folder.
            lakehouse_id (str): The ID of the lakehouse.
        """
        full_path = f"{lakehouse_id}/{lakehouse_dir_path}"
        try:
            if lakehouse_dir_path == "Tables/":
                OneLakeUtils._delete_all_tables(file_system_client, lakehouse_id)
            elif lakehouse_dir_path.startswith("Tables/"):
                table_name = lakehouse_dir_path.split('/')[-1]
                OneLakeUtils._delete_table(file_system_client, table_name, lakehouse_id)
            elif lakehouse_dir_path == "Files/":
                OneLakeUtils._delete_all_files(file_system_client, lakehouse_id)
            else:
                OneLakeUtils._delete_file_or_folder(file_system_client, full_path)
        except Exception as e:
            print(f"Error processing '{lakehouse_dir_path}': {str(e)}")

    @staticmethod
    def _delete_table(file_system_client: FileSystemClient, table_name: str, lakehouse_id: str) -> None:
        table_path = f"{lakehouse_id}/Tables/{table_name}"
        try:
            if file_system_client.get_directory_client(table_path).exists():
                file_system_client.delete_directory(table_path)
                print(f"Deleted table: Tables/{table_name}")
            else:
                print(f"Table not found: Tables/{table_name}")
        except Exception as e:
            print(f"Error deleting table 'Tables/{table_name}': {str(e)}")

    @staticmethod
    def _delete_all_tables(file_system_client: FileSystemClient, lakehouse_id: str) -> None:
        tables_path = f"{lakehouse_id}/Tables"
        try:
            paths = list(file_system_client.get_paths(path=tables_path))
            deleted_count = 0
            for path in paths:
                if path.is_directory and not path.name.endswith('_delta_log'):
                    table_name = path.name.split('/')[-1]
                    OneLakeUtils._delete_table(file_system_client, table_name, lakehouse_id)
                    deleted_count += 1
            print(f"Deleted {deleted_count} tables successfully")
        except Exception as e:
            print(f"Error deleting all tables: {str(e)}")

    @staticmethod
    def _delete_all_files(file_system_client: FileSystemClient, lakehouse_id: str) -> None:
        files_path = f"{lakehouse_id}/Files"
        try:
            paths = list(file_system_client.get_paths(path=files_path, recursive=True))
            deleted_count = 0
            for path in paths:
                if not path.is_directory:
                    file_system_client.get_file_client(path.name).delete_file()
                    deleted_count += 1
            print(f"Deleted {deleted_count} files successfully")
        except Exception as e:
            print(f"Error deleting all files: {str(e)}")

    @staticmethod
    def _delete_file_or_folder(file_system_client: FileSystemClient, full_path: str) -> None:
        try:
            if file_system_client.get_directory_client(full_path).exists():
                file_system_client.delete_directory(full_path)
                print(f"Deleted directory: {full_path.split('/', 1)[1]}")
            elif file_system_client.get_file_client(full_path).exists():
                file_system_client.get_file_client(full_path).delete_file()
                print(f"Deleted file: {full_path.split('/', 1)[1]}")
            else:
                print(f"Path not found: {full_path.split('/', 1)[1]}")
        except Exception as e:
            print(f"Error deleting '{full_path.split('/', 1)[1]}': {str(e)}")

class FabricAPIs:
    """
    A class to handle various operations with Microsoft Fabric APIS.
    """
    def __init__(self):
        self.workspace_id = os.getenv("WORKSPACE_ID")
        self.lakehouse_id = os.getenv("LAKEHOUSE_ID")
        self.lakehouse_name = os.getenv("LAKEHOUSE_NAME")

    def import_notebook_to_fabric(self, token: str, upload_from: str, source_path: str,
                                default_lakehouse_id: str = None,
                                default_lakehouse_workspace_id: str = None,
                                environment_id: str = None,
                                environment_workspace_id: str = None,
                                known_lakehouses: list = None,
                                max_workers: int = 5):
        """
        Imports a notebook into Microsoft Fabric from various sources.

        Args:
            token (str): Authentication token for API access.
            upload_from (str): Source of the notebook ('local', 'lakehouse', or 'github').
            source_path (str): Path or URL of the notebook to import.
            default_lakehouse_id (str, optional): ID of the default lakehouse.
            default_lakehouse_workspace_id (str, optional): ID of the default lakehouse workspace.
            environment_id (str, optional): ID of the environment.
            environment_workspace_id (str, optional): ID of the environment workspace.
            known_lakehouses (list, optional): List of known lakehouse IDs.
            max_workers (int, optional): Maximum number of worker threads for concurrent imports.

        This function orchestrates the import of notebooks from various sources into Microsoft Fabric.
        It handles different upload sources, manages metadata, and uses multithreading for efficiency.
        """
        original_lakehouse_id = os.getenv("LAKEHOUSE_ID")
        lakehouse_id = default_lakehouse_id or original_lakehouse_id
        lakehouse_name = os.getenv("LAKEHOUSE_NAME")
        default_lakehouse_workspace_id = default_lakehouse_workspace_id or os.getenv("WORKSPACE_ID")
        workspace_id = environment_workspace_id or default_lakehouse_workspace_id
        environment_id = environment_id or "6524967a-18dc-44ae-86d1-0ec903e7ca05"

        if not workspace_id:
            raise ValueError("workspace_id is required. Please provide it or set WORKSPACE_ID in your environment variables.")

        if not lakehouse_id:
            raise ValueError("lakehouse_id is required. Please provide it or set LAKEHOUSE_ID in your environment variables.")

        print(f"Using parameters:\nworkspace_id: {workspace_id}\nlakehouse_id: {lakehouse_id}\ndefault_lakehouse_workspace_id: {default_lakehouse_workspace_id}")

        notebooks_to_import = self._get_notebooks_to_import(upload_from, source_path)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for notebook_path in notebooks_to_import:
                future = executor.submit(
                    self._process_single_notebook,
                    upload_from, source_path, notebook_path, token, workspace_id, lakehouse_id, lakehouse_name,
                    default_lakehouse_workspace_id, environment_id, known_lakehouses, default_lakehouse_id, original_lakehouse_id
                )
                futures.append(future)

            for future in as_completed(futures):
                result = future.result()
                if result:
                    print(f"Successfully imported: {result}")
                else:
                    print(f"Failed to import a notebook")

    def _get_notebooks_to_import(self, upload_from, source_path):
        """
        Retrieves a list of notebooks to import based on the source.

        Args:
            upload_from (str): Source of the notebook ('local', 'lakehouse', or 'github').
            source_path (str): Path or URL of the notebook(s) to import.

        Returns:
            list: A list of notebook paths to import.

        Determines which notebooks to import based on the source. For local files,
        it can handle both single files and directories.
        """
        if upload_from == "local":
            if os.path.isdir(source_path):
                return [os.path.join(source_path, f) for f in os.listdir(source_path) if f.endswith('.ipynb')]
            else:
                return [source_path]
        elif upload_from == "lakehouse":
            return [source_path]
        elif upload_from == "github":
            return [source_path]
        else:
            print(f"Unsupported upload_from value: {upload_from}")
            return []

    def _process_single_notebook(self, upload_from, source_path, notebook_path, token, workspace_id, lakehouse_id, lakehouse_name,
                                default_lakehouse_workspace_id, environment_id, known_lakehouses, default_lakehouse_id, original_lakehouse_id):
        """
        Processes and imports a single notebook.

        Args:
            upload_from (str): Source of the notebook.
            source_path (str): Original source path or URL.
            notebook_path (str): Specific path of the notebook file.
            token (str): Authentication token.
            workspace_id (str): ID of the workspace.
            lakehouse_id (str): ID of the lakehouse.
            lakehouse_name (str): Name of the lakehouse.
            default_lakehouse_workspace_id (str): ID of the default lakehouse workspace.
            environment_id (str): ID of the environment.
            known_lakehouses (list): List of known lakehouse IDs.
            default_lakehouse_id (str): ID of the default lakehouse.
            original_lakehouse_id (str): Original ID of the lakehouse from environment variables.

        Returns:
            str: Name of the imported notebook if successful, None otherwise.

        Handles the entire process of importing a single notebook, including loading content,
        updating metadata, and creating the notebook in Fabric.
        """
        try:
            timestamp = datetime.now().strftime('%Y-%m-%d--%H-%M-%S')
            
            if upload_from == "github":
                repo_parts = source_path.split('/')
                owner = repo_parts[3]
                repo_name = repo_parts[4]
                file_path = '/'.join(repo_parts[7:])
                
                github_path = f"github/{owner}/{repo_name}/{file_path}"
                notebook_name = f"{github_path}--{timestamp}"
            elif upload_from == "local":
                notebook_name = f"local/{os.path.basename(notebook_path)}--{timestamp}"
            elif upload_from == "lakehouse":
                notebook_name = f"lakehouse/{lakehouse_name}/{notebook_path}--{timestamp}"
            else:
                notebook_name = f"{upload_from}_{os.path.splitext(os.path.basename(notebook_path))[0]}--{timestamp}"

            # Use the original_lakehouse_id for downloading when upload_from is 'lakehouse'
            download_lakehouse_id = original_lakehouse_id if upload_from == 'lakehouse' else lakehouse_id
            notebook_json = self._load_notebook_content(upload_from, source_path, notebook_path, token, workspace_id, download_lakehouse_id)
            
            if not notebook_json:
                return None

            new_metadata = {
                "language_info": {"name": "python"},
                "trident": {
                    "environment": {
                        "environmentId": environment_id,
                        "workspaceId": workspace_id
                    },
                    "lakehouse": {
                        "default_lakehouse_workspace_id": default_lakehouse_workspace_id
                    }
                }
            }

            if default_lakehouse_id:
                new_metadata["trident"]["lakehouse"]["default_lakehouse"] = default_lakehouse_id
            else:
                new_metadata["trident"]["lakehouse"]["default_lakehouse"] = lakehouse_id
                new_metadata["trident"]["lakehouse"]["default_lakehouse_name"] = lakehouse_name

            if known_lakehouses:
                new_metadata["trident"]["lakehouse"]["known_lakehouses"] = [{"id": lh} for lh in known_lakehouses]

            print(f"Updated notebook metadata: {json.dumps(new_metadata, indent=2)}")

            new_notebook = {
                "nbformat": 4,
                "nbformat_minor": 5,
                "cells": notebook_json.get("cells", []),
                "metadata": new_metadata
            }

            base64_notebook_content = base64.b64encode(json.dumps(new_notebook).encode('utf-8')).decode('utf-8')
            return self._create_notebook(notebook_name, base64_notebook_content, token, workspace_id)
        except Exception as e:
            print(f"Error processing notebook {notebook_path}: {str(e)}")
            return None

    def _load_notebook_content(self, upload_from, source_path, notebook_path, token, workspace_id, lakehouse_id):
        """
        Loads the content of a notebook from various sources.

        Args:
            upload_from (str): Source of the notebook ('local', 'lakehouse', or 'github').
            source_path (str): Path or URL of the notebook.
            notebook_path (str): Specific path of the notebook file.
            token (str): Authentication token.
            workspace_id (str): ID of the workspace.
            lakehouse_id (str): ID of the lakehouse.

        Returns:
            dict: JSON content of the notebook.

        Loads notebook content from local files, lakehouses, or GitHub repositories.
        """
        if upload_from == "local":
            return self._load_local_notebook(notebook_path)
        elif upload_from == "lakehouse":
            return self._load_lakehouse_notebook(notebook_path, token, workspace_id, lakehouse_id)
        elif upload_from == "github":
            return self._load_github_notebook(source_path)
        else:
            print("Invalid upload_from parameter. Use 'local', 'lakehouse', or 'github'.")
            return None

    def _load_local_notebook(self, source_path):
        if os.path.exists(source_path):
            with open(source_path, "r", encoding="utf-8") as file:
                return json.load(file)
        else:
            print(f"Failed to locate the local notebook file: {source_path}")
            return None

    def _load_lakehouse_notebook(self, source_path, token, workspace_id, lakehouse_id):
        token_credential = DefaultAzureCredential()
        file_system_client = DataLakeServiceClient(
            f"https://onelake.dfs.fabric.microsoft.com",
            credential=token_credential
        ).get_file_system_client(workspace_id)

        temp_file_path = self._download_from_lakehouse_temp(file_system_client, source_path, lakehouse_id)
        if temp_file_path:
            with open(temp_file_path, "r", encoding="utf-8") as file:
                notebook_json = json.load(file)
            os.unlink(temp_file_path)  # Delete the temporary file
            return notebook_json
        else:
            print("Failed to download the notebook file from lakehouse.")
            return None

    def _load_github_notebook(self, repo_url):
        try:
            return self._download_file_from_github(repo_url)
        except Exception as e:
            print(f"Failed to download the notebook file from GitHub: {str(e)}")
            return None

    def _download_file_from_github(self, repo_url: str) -> dict:
        parts = repo_url.split('/')
        owner, repo, branch = parts[3], parts[4], parts[6]
        file_path = '/'.join(parts[7:])
        raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{file_path}"
        print(f"Attempting to download from: {raw_url}")
        response = requests.get(raw_url)
        response.raise_for_status()
        return json.loads(response.text)

    def _create_notebook(self, notebook_name, base64_notebook_content, token, workspace_id):
        """
        Creates a new notebook in Microsoft Fabric.

        Args:
            notebook_name (str): Name of the new notebook.
            base64_notebook_content (str): Base64 encoded content of the notebook.
            token (str): Authentication token.
            workspace_id (str): ID of the workspace.

        Returns:
            str: Name of the created notebook if successful, None otherwise.

        Sends a request to the Fabric API to create a new notebook with the provided content and metadata.
        """
        endpoint = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items"
        payload = {
            "displayName": notebook_name,
            "type": "Notebook",
            "description": "Notebook created via API",
            "definition": {
                "format": "ipynb",
                "parts": [{"path": "artifact.content.ipynb", "payload": base64_notebook_content, "payloadType": "InlineBase64"}]
            }
        }
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

        response = requests.post(endpoint, json=payload, headers=headers)
        response.raise_for_status()

        if response.status_code == 201:
            print(f"Notebook created successfully. ID: {response.json().get('id')}")
            return notebook_name
        elif response.status_code == 202:
            location_url = response.headers.get("Location")
            poll_result = self._poll_notebook_creation(location_url, token)
            if poll_result["success"]:
                print(f"Notebook created successfully. ID: {poll_result['id']}")
                return notebook_name
        return None

    def _poll_notebook_creation(self, location_url: str, token: str, max_retries: int = 20, retry_interval: int = 5) -> dict:
        """
        Polls the status of a notebook creation operation.

        Args:
            location_url (str): URL to poll for creation status.
            token (str): Authentication token.
            max_retries (int): Maximum number of retry attempts.
            retry_interval (int): Interval between retry attempts in seconds.

        Returns:
            dict: A dictionary containing success status and details of the operation.

        Continuously checks the status of a notebook creation operation until it succeeds,
        fails, or exceeds the maximum number of retries.
        """
        headers = {"Authorization": f"Bearer {token}"}
        for attempt in range(max_retries):
            try:
                poll_response = requests.get(location_url, headers=headers)
                poll_response.raise_for_status()
                
                response_json = poll_response.json()
                status = response_json.get('status', '').lower()
                
                if status == 'succeeded':
                    print(f"Poll response: {response_json}")
                    return {"success": True, "id": response_json.get('resourceId'), "details": response_json}
                elif status in ['failed', 'canceled']:
                    print(f"Poll response: {response_json}")
                    return {"success": False, "details": response_json}
                time.sleep(retry_interval)
            except requests.RequestException as e:
                print(f"Error during polling: {e}")
                time.sleep(retry_interval)
        
        return {"success": False, "details": "Polling exceeded maximum retries"}

    def _download_from_lakehouse_temp(self, file_system_client, source_path: str, lakehouse_id: str) -> str:
        """
        Downloads a file from a lakehouse to a temporary location.

        Args:
            file_system_client: Azure Data Lake file system client.
            source_path (str): Path of the file in the lakehouse.
            lakehouse_id (str): ID of the lakehouse.

        Returns:
            str: Path to the downloaded temporary file, or None if download fails.

        Downloads a file from a specified lakehouse to a temporary local file and
        returns the path to this temporary file.
        """
        import tempfile
        
        lakehouse_path = f"{lakehouse_id}/{source_path}"
        
        try:
            file_client = file_system_client.get_file_client(lakehouse_path)
            
            # Create a temporary file
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".ipynb")
            temp_file_path = temp_file.name
            
            # Download the file content
            with open(temp_file_path, "wb") as file_handle:
                download = file_client.download_file()
                download.readinto(file_handle)
            
            print(f"File downloaded to temporary location: {temp_file_path}")
            return temp_file_path
        
        except Exception as e:
            print(f"Error downloading file from '{source_path}': {str(e)}")
            return None
        
    def run_notebook_job(self, token: str, notebook_id: str, workspace_id: str = None, lakehouse_id: str = None, lakehouse_name: str = None) -> str:
        """
        Run a Spark notebook job.

        Args:
            token (str): The authentication token.
            notebook_id (str): The ID of the notebook to run.
            workspace_id (str, optional): The ID of the workspace. If not provided, uses the value from environment variables or None.
            lakehouse_id (str, optional): The ID of the lakehouse. If not provided, uses the value from environment variables or None.
            lakehouse_name (str, optional): The name of the lakehouse. If not provided, uses the value from environment variables or None.

        Returns:
            str: The location URL of the triggered job, or None if the job failed to trigger.
        """
        workspace_id = workspace_id or self.workspace_id or None
        lakehouse_id = lakehouse_id or self.lakehouse_id or None
        lakehouse_name = lakehouse_name or self.lakehouse_name or None

        if not workspace_id:
            print("Warning: workspace_id is not provided and not set in environment variables.")

        endpoint = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items/{notebook_id}/jobs/instances?jobType=RunNotebook"
        
        payload = {
            "executionData": {
                "useStarterPool": True
            }
        }

        if lakehouse_id and lakehouse_name:
            payload["executionData"]["defaultLakehouse"] = {
                "name": lakehouse_name,
                "id": lakehouse_id,
            }
        elif lakehouse_id or lakehouse_name:
            print("Warning: Both lakehouse_id and lakehouse_name must be provided to set the default lakehouse.")

        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        response = requests.post(endpoint, json=payload, headers=headers)
        if response.status_code == 202:
            return response.headers.get("Location")
        else:
            print(f"Failed to trigger notebook job. Status code: {response.status_code}, Response text: {response.text}")
            return None

    def trigger_pipeline_job(self, token: str, pipeline_id: str, workspace_id: str = None) -> str:
        """
        Trigger a data pipeline job.

        Args:
            token (str): The authentication token.
            pipeline_id (str): The ID of the pipeline to trigger.
            workspace_id (str, optional): The ID of the workspace. If not provided, uses the value from environment variables or None.

        Returns:
            str: The location URL of the triggered job, or None if the job failed to trigger.
        """
        workspace_id = workspace_id or self.workspace_id or None

        if not workspace_id:
            print("Warning: workspace_id is not provided and not set in environment variables.")

        endpoint = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id or ''}/items/{pipeline_id}/jobs/instances?jobType=Pipeline"
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        response = requests.post(endpoint, headers=headers)
        if response.status_code == 202:
            return response.headers.get("Location")
        else:
            print(f"Failed to trigger pipeline job. Status code: {response.status_code}, Response text: {response.text}")
            return None

    def trigger_table_maintenance_job(self, table_name: str, token: str) -> str:
        """
        Trigger a Delta table maintenance job.

        Args:
            table_name (str): The name of the table to maintain.
            token (str): The authentication token.

        Returns:
            str: The location URL of the triggered job, or None if the job failed to trigger.
        """
        endpoint = f"https://api.fabric.microsoft.com/v1/workspaces/{self.workspace_id}/lakehouses/{self.lakehouse_id}/jobs/instances?jobType=TableMaintenance"
        payload = {
            "executionData": {
                "tableName": table_name,
                "optimizeSettings": {"vOrder": True},
                "vacuumSettings": {"retentionPeriod": "7:01:00:00"}
            }
        }
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        response = requests.post(endpoint, json=payload, headers=headers)
        if response.status_code == 202:
            return response.headers.get("Location")
        else:
            print(f"Failed to trigger table maintenance job. Status code: {response.status_code}, Response text: {response.text}")
            return None

    def trigger_table_maintenance_for_all_tables(self, token: str, file_system_client: FileSystemClient, batch_size: int = 5, batch_delay: int = 60):
        """
        Trigger maintenance jobs for all tables in the lakehouse.

        Args:
            token (str): The authentication token.
            file_system_client (FileSystemClient): The file system client for OneLake storage.
            batch_size (int, optional): Number of tables to process in each batch. Defaults to 5.
            batch_delay (int, optional): Delay between batches in seconds. Defaults to 60.
        """
        # Get the filtered subdirectory names for "Tables"
        filtered_tables = self.list_items(file_system_client=file_system_client, target_directory_path="Tables")

        # Iterate over the filtered tables in batches
        for i in range(0, len(filtered_tables), batch_size):
            batch_tables = filtered_tables[i:i + batch_size]
            for table_name in batch_tables:
                try:
                    result = self.trigger_table_maintenance_job(table_name=table_name, token=token)
                    if result is not None:
                        print(f"Table maintenance job triggered for table: {table_name}")
                    else:
                        print(f"Failed to trigger table maintenance job for table: {table_name}")
                except Exception as e:
                    print(f"An error occurred for table {table_name}: {e}")
            
            # Delay between batches
            if i + batch_size < len(filtered_tables):
                print(f"Waiting for {batch_delay} seconds before triggering the next batch...")
                time.sleep(batch_delay)