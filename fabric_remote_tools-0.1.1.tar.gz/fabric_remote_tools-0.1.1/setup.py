import os
from setuptools import setup, find_packages

# Get the absolute path to requirements.txt
requirements_file = os.path.join(os.path.dirname(__file__), 'requirements.txt')

# Read the contents of requirements.txt
with open(requirements_file) as f:
    install_requires = f.read().splitlines()

setup(
    name='fabric_remote_tools',
    version='0.1.1',
    packages=find_packages(),
    install_requires=install_requires
)
