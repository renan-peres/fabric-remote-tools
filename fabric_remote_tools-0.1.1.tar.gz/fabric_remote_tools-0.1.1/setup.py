from setuptools import setup, find_packages

setup(
    name='fabric_remote_tools',
    version='0.1.1',
    packages=find_packages(),
    install_requires=[
        'python-dotenv==1.0.1', 
        'typing==3.7.4.3', 
        'pandas==2.2.2', 
        'polars==1.0.0', 
        'pyarrow==16.1.0', 
        'deltalake==0.18.2', 
        'connectorx==0.3.3',
        'pyodbc==5.1.0', 
        'pymssql==2.3.0', 
        'duckdb==1.1.0', 
        'requests==2.32.3', 
        'azure-identity==1.17.0',  
        'azure-devops==7.1.0b4', 
        'azure-storage-file-datalake==12.15.0'  
    ]
)

# python setup.py sdist
