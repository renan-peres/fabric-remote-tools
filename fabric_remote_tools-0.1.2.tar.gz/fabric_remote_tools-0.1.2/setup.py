from setuptools import setup, find_packages

setup(
    name='fabric_remote_tools',
    version='0.1.2',
    packages=find_packages(),
    python_requires='>=3.8',
    install_requires=[
        'python-dotenv>=1.0.0',
        'pandas>=2.0.0',
        'polars>=1.0.0',
        'pyarrow>=15.0.0',
        'deltalake>=0.18.0',
        'connectorx>=0.3.0',
        'pyodbc>=5.0.0',
        'pymssql>=2.2.0',
        'duckdb>=1.0.0',
        'requests>=2.31.0',
        'azure-identity>=1.15.0',
        'azure-devops>=7.0.0',
        'azure-storage-file-datalake>=12.13.0',
    ],
)
